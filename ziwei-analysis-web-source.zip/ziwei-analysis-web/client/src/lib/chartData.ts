// Parsed from 文墨天機紫微斗數命盤範例 Pasted_content_04.txt
export type ParsedPalace = { name: string; branch: string; extra?: string; main: string; support: string; minor: string; limit: string; small: string; yearly: string; isBody?: boolean; isOrigin?: boolean };

export const chartProfile = {
  gender: "男", longitude: "121.300", birthTime: "1981-4-6 18:0", trueSolarTime: "1981-4-6 18:2", lunarTime: "辛酉年三月初二日酉時", pillars: "辛酉 壬辰 甲寅 癸酉", fiveElements: "金四局", chartType: "三合盤(天盤)", bodyMaster: "天同", lifeMaster: "武曲", yearRuler: "未", bodyPalace: "丑", apiVersion: "1.1.5", appVersion: "2.5.20", installCode: "C5VUC",
} as const;

export const parsedPalaces: ParsedPalace[] = [
  { name: "交友宮", branch: "庚子", main: "武曲[旺][↓權][↑科],天府[廟]", support: "火星[陷]", minor: "天喜[旺],天傷[陷],副旬[陷]", limit: "74~83虛歲", small: "6,18,30,42,54虛歲", yearly: "4,16,28,40,52虛歲" },
  { name: "遷移宮", branch: "辛丑", extra: "身宮", main: "太陽[不][生年權][↓權],太陰[廟][↑忌]", support: "文昌[廟][生年忌][↓忌],文曲[廟][生年科][↓科]", minor: "恩光[廟],天貴[旺],龍池[平],鳳閣[平],旬空[平],年解[得],華蓋[陷]", limit: "64~73虛歲", small: "7,19,31,43,55虛歲", yearly: "5,17,29,41,53虛歲", isBody: true },
  { name: "疾厄宮", branch: "庚寅", main: "貪狼[平]", support: "天魁,地空[陷]", minor: "天使[平],天巫,大耗[陷],劫煞,月德", limit: "54~63虛歲", small: "8,20,32,44,56虛歲", yearly: "6,18,30,42,54虛歲" },
  { name: "財帛宮", branch: "辛卯", extra: "來因", main: "天機[旺][↑科],巨門[廟][生年祿][↓祿][↑忌]", support: "無", minor: "天姚[廟],臺輔,天虛[廟]", limit: "44~53虛歲", small: "9,21,33,45,57虛歲", yearly: "7,19,31,43,55虛歲", isOrigin: true },
  { name: "子女宮", branch: "壬辰", main: "紫微[得][↓權],天相[得]", support: "無", minor: "天才[陷],天月,副截[陷],龍德", limit: "34~43虛歲", small: "10,22,34,46,58虛歲", yearly: "8,20,32,44,56虛歲" },
  { name: "夫妻宮", branch: "癸巳", main: "天梁[得][↑科]", support: "無", minor: "天福[旺],截空[廟],破碎[陷]", limit: "24~33虛歲", small: "11,23,35,47,59虛歲", yearly: "9,21,33,45,57虛歲" },
  { name: "兄弟宮", branch: "甲午", main: "七殺[旺]", support: "左輔[旺],天鉞", minor: "紅鸞[旺],天廚,咸池[陷],天德[旺]", limit: "14~23虛歲", small: "12,24,36,48,60虛歲", yearly: "10,22,34,46,58虛歲" },
  { name: "命宮", branch: "乙未", main: "無", support: "鈴星[利]", minor: "三臺[廟],八座[平],寡宿[不]", limit: "4~13虛歲", small: "1,13,25,37,49虛歲", yearly: "11,23,35,47,59虛歲" },
  { name: "父母宮", branch: "丙申", main: "廉貞[廟][↓忌]", support: "右弼[不],陀羅[陷],地劫[廟]", minor: "無", limit: "114~123虛歲", small: "2,14,26,38,50虛歲", yearly: "12,24,36,48,60虛歲" },
  { name: "福德宮", branch: "丁酉", main: "無", support: "祿存[廟]", minor: "天官[平],天哭[不]", limit: "104~113虛歲", small: "3,15,27,39,51虛歲", yearly: "1,13,25,37,49虛歲" },
  { name: "田宅宮", branch: "戊戌", main: "破軍[旺]", support: "擎羊[廟]", minor: "天壽[廟],解神[廟],天空[陷],陰煞", limit: "94~103虛歲", small: "4,16,28,40,52虛歲", yearly: "2,14,26,38,50虛歲" },
  { name: "官祿宮", branch: "己亥", main: "天同[廟]", support: "天馬[平]", minor: "天刑[陷],封誥,孤辰[陷],蜚廉", limit: "84~93虛歲", small: "5,17,29,41,53虛歲", yearly: "3,15,27,39,51虛歲" },
];

export const majorLimits = [
  { number: 1, palace: "乙未", years: "1984–1993", transforms: "天機祿、天梁權、紫微科、太陰忌", overlayStars: {} },
  { number: 2, palace: "甲午", years: "1994–2003", transforms: "廉貞祿、破軍權、武曲科、太陽忌", overlayStars: {} },
  { number: 3, palace: "癸巳", years: "2004–2013", transforms: "破軍祿、巨門權、太陰科、貪狼忌", overlayStars: {} },
  { number: 4, palace: "壬辰", years: "2014–2023", transforms: "天梁祿、紫微權、左輔科、武曲忌", overlayStars: {} },
  { number: 5, palace: "辛卯", years: "2024–2033", transforms: "巨門祿、太陽權、文曲科、文昌忌", overlayStars: { "命宮": ["陀羅"], "兄弟宮": ["紅鸞"], "父母宮": ["擎羊"], "福德宮": ["祿存"] }, current: true },
  { number: 6, palace: "庚寅", years: "2034–2043", transforms: "太陽祿、武曲權、太陰科、天同忌", overlayStars: {} },
  { number: 7, palace: "辛丑", years: "2044–2053", transforms: "廉貞祿、破軍權、武曲科、太陽忌", overlayStars: {} },
  { number: 8, palace: "庚子", years: "2054–2063", transforms: "天機祿、天梁權、紫微科、太陰忌", overlayStars: {} },
];

export const currentYear = { year: 2026, age: 46, branch: "丙午", transforms: "天同祿、天機權、文昌科、廉貞忌", overlayStars: {} } as const;
export const annualSamples = [
  { year: 2024, age: 44, branch: "甲辰", transforms: "廉貞祿、破軍權、武曲科、太陽忌", overlayStars: { "命宮": ["祿存"], "財帛宮": ["天喜"] } },
  { year: 2025, age: 45, branch: "乙巳", transforms: "天機祿、天梁權、紫微科、太陰忌", overlayStars: { "命宮": ["紅鸞"], "父母宮": ["陀羅"] } },
  currentYear,
  { year: 2028, age: 48, branch: "戊申", transforms: "貪狼祿、太陰權、右弼科、天機忌", overlayStars: { "命宮": ["陀羅"], "交友宮": ["天喜"] } },
];

export const parserMeta = { source: "Pasted_content_04.txt", note: "已將文墨天機原始欄位保留，供逐宮核對與 OCR 對照。" } as const;
